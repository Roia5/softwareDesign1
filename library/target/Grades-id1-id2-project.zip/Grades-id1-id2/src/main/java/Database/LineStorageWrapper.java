package Database;

import il.ac.technion.cs.sd.grades.ext.LineStorage;

/**
 * Created by dani9590 on 24/04/17.
 */
public class LineStorageWrapper implements DatabaseInterface {
    public void appendLine(String string) {
        LineStorage.appendLine(string);
    }

    public String read(int lineNumber) throws InterruptedException {
        return LineStorage.read(lineNumber);
    }

    public int numberOfLines() throws InterruptedException {
        return LineStorage.numberOfLines();
    }
}
