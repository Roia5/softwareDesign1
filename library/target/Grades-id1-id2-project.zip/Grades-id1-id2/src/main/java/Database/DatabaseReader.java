/**
 * Created by dani9590 on 23/04/17.
 */
package Database;

import il.ac.technion.cs.sd.grades.ext.LineStorage;

import java.util.Arrays;

public class DatabaseReader implements ReaderInterface{
    private void checkInterfaceValid() {
        if (databaseInterface == null)
            throw new RuntimeException("You need to pass a database library!");
    }
    private DatabaseInterface databaseInterface = null;
    public DatabaseReader(DatabaseInterface userDatabaseLibrary) {
        databaseInterface = userDatabaseLibrary;
    }

    public DatabaseReader() {
        databaseInterface = new LineStorageWrapper();
    }

    public void insertStrings(String[] strings) {
        checkInterfaceValid();
        String[] stringsToInsert = new String[strings.length];
        System.arraycopy(strings,0,stringsToInsert,0,stringsToInsert.length);
        Arrays.sort(stringsToInsert);

        for (int i = 0; i < stringsToInsert.length; i++) {
            databaseInterface.appendLine(stringsToInsert[i]);
        }
    }

    public String find(String id) throws InterruptedException {
        checkInterfaceValid();
        int last = databaseInterface.numberOfLines() - 1, first = 0;
        while (last >= first) {
            int middle = first + (last - first) / 2;
            String[] keyValue = databaseInterface.read(middle).split(",");
            int compareResult = keyValue[0].compareTo(id);
            if (compareResult > 0)
                last = middle - 1;
            else
                first = middle + 1;
            if (compareResult == 0)
                return keyValue[1];
        }
        throw new InterruptedException();
    }

    public int numberOfLines() throws InterruptedException{
        checkInterfaceValid();
        return databaseInterface.numberOfLines();
    }

}
