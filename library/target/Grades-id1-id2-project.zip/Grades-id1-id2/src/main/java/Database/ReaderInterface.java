package Database;

/**
 * Created by Roey on 26/04/2017.
 */
public interface ReaderInterface {
    public void insertStrings(String[] strings);
    public String find(String id) throws InterruptedException;
    public int numberOfLines() throws InterruptedException;
}
