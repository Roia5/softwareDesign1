package Database;

/**
 * Created by dani9590 on 23/04/17.
 */
public interface DatabaseInterface {
    void appendLine(String st);
    String read(int numberOfLine) throws InterruptedException;
    int numberOfLines() throws InterruptedException;

}
